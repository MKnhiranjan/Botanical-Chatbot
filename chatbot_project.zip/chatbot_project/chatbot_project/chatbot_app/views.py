from django.shortcuts import render,redirect
import re
from django.core.mail import send_mail
from django.http import HttpResponse
from sklearn.preprocessing import LabelEncoder
from .models import ChatbotResponse
from .models import ChatHistory
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.tree import DecisionTreeClassifier
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk
# nltk.download('punkt')
# nltk.download('stopwords')
# nltk.download('wordnet')
# file_path = 'C:\\Users\\mypc\\Downloads\\chatbot_project\\chatbot_project\\chatbot_app\\data.csv'
file_path='chatbot_app\\data.csv'
df = pd.read_csv(file_path)
print(df)
# Text preprocessing
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))


def loginpage(request):
    page='login'
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        print(username)
        try:
            user=User.objects.get(username=username)
        except:
            messages.error(request,"user doesnot exist")
        user=authenticate(request,username=username,password=password)
        if user!=None:
            login(request,user)
            return redirect('main')
        else:

            return redirect("login")
    else:
        return render(request,'index.html',{'page':page})
    
def logoutPage(request):
    logout(request)
    return redirect('index.html')

def registrationpage(request):
    page='register'
    form=UserCreationForm()
    if request.method=="POST":
        form=UserCreationForm(request.POST)
        # print(user)
        if form.is_valid():
            user=form.save()
            user.save()
            login(request,user)
            return render(request,'main.html',{'user':user})
        else:
            messages.error(request,"Enter a valid username and password")
            return redirect('registration')
    return render(request,'index.html',{'form':form,'page':page})


def preprocess_text(text):
    if text is not None:
        tokens = word_tokenize(text.lower())  # Tokenization and lowercasing
        tokens = [lemmatizer.lemmatize(token) for token in tokens if token.isalnum()]  # Lemmatization
        tokens = [token for token in tokens if token not in stop_words]  # Remove stopwords
        return ' '.join(tokens)
    else:
        return 'emo'

# Preprocess the questions
df['Question'] = df['Input'].apply(preprocess_text)

# Convert text data into numerical features using bag-of-words representation
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(df['Question'])

# Train a decision tree classifier
classifier = DecisionTreeClassifier()
classifier.fit(X, df['Response'])

def predict_answer(input_question):
    input_question = preprocess_text(input_question)
    input_vector = vectorizer.transform([input_question])
    prediction = classifier.predict(input_vector)
    return prediction[0]

# @login_required(login_url='login')
def chatbot(request):
    last_user_message_index = -1  # Default value if no user messages exist
    user_input = request.POST.get('user_input')
    bot_response = predict_answer(user_input)
    # Save the interaction to the database
    if user_input is not None:
        chat_history = ChatHistory( user_input=user_input, bot_response=bot_response)
        chat_history.save()
    if request.method == 'POST':
        user_input = request.POST.get('user_input')
        if user_input is not None:
            # Process user input and get a bot response (you can use your logic here)
            bot_response = predict_answer(user_input)

            # Store the user interaction in the database
            

            messages = request.session.get('chat_messages', [])
            messages.append({'user': True, 'text': user_input})
            messages.append({'user': False, 'text': bot_response})
            request.session['chat_messages'] = messages

            # Update the last_user_message_index
            last_user_message_index = len(messages) # Index of the last user message
    chat_history_entries = ChatHistory.objects.all().order_by('-timestamp') 
 # Debugging statement
    messages = request.session.get('chat_messages', [])
    return render(request, 'chatbot.html', {'messages': messages, 'last_user_message_index': last_user_message_index, 'chat_history_entries': chat_history_entries})
def delete_entry(request, entry_id):
    try:
        entry_to_delete = ChatHistory.objects.get(id=entry_id)
        entry_to_delete.delete()
    except ChatHistory.DoesNotExist:
        pass  # Handle the case when the entry does not exist (optional)

    return redirect('chatbot')  
# from django.core.mail import send_mail
from django.http import HttpResponse

def test_page(request):
    return render(request, 'test.html')

@login_required(login_url='login')
def ai(request):
    return render(request,'ai.html')


def page(request):
    return render(request,'main.html')