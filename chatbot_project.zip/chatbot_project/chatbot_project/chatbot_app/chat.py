import streamlit as st
import ai

st.title("Chatbot")

st.markdown(
    """
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .stApp {
        margin: 0 auto;
        width:100vw;
        background-color: #F2EFE5;
        padding: 20px;
    }
    .stButton > button {
        color: white;
        border-color: #3498db;
        border-radius: 5px;
    }
    .stTextInput > div > div {
        background-color: #ffffff;
        border-radius: 5px;
    }
    .stTextInput > div > input {
        border: none;
        outline: none;
        background-color: rgb(117 194 246);
    }
    .stChatFloatingInputContainer {
        background-color: #F2EFE5 !important;
    }
    header {
        background-color: #0D9276!important;
    }
    h1 {
        color: #0D9276 !important;
    }
    textarea {
        background-color: #D2E3C8 !important;
        outline-width: 0px !important;
        color: #0B2447 !important;
    }
    .st-cg {
        caret-color: rgb(0, 0, 0)!important;
    }
    svg {
        color: #181823 !important;
    }
    textarea {
        font-weight: medium !important;
        font-family: arial !important;
    }
    .css-4oy321 {
        background-color: #0baaabcf !important;
    }
    .css-1c7y2kd {
        background-color: #a7ecee;
    }

    .st-emotion-cache-1c7y2kd {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
    padding: 1rem;
    border-radius: 0.5rem;
    background-color: #28a745 !important;
    }

    .st-emotion-cache-1c7y2kd{
    color:white;
    background-color:#28a745 !important;
    }

    .st-emotion-cache-4oy321 {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
    padding: 1rem 0px 1rem 1rem;
    border-radius: 0.5rem;
    background-color:#ccc !important;
}

.st-emotion-cache-janbn0{
    background-color:black !important;

}
    </style>
    """,
    unsafe_allow_html=True
)

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat messages from history on app rerun
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# React to user input
if prompt := st.chat_input("What is up?"):
    # Display user message in chat message container
    st.chat_message("user").markdown(prompt)
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})

    response = ai.g_ai.generate_content(prompt)
    # Display assistant response in chat message container
    with st.chat_message("assistant"):
        st.markdown(response.text)
    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": response.text    })